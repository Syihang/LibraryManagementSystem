-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: librarymanagementsystem
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `admin_id` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `account` char(12) NOT NULL COMMENT '账号',
  `password` varchar(12) NOT NULL COMMENT '密码',
  `admin_name` varchar(12) NOT NULL COMMENT '姓名',
  `telephone` char(11) NOT NULL COMMENT '联系电话',
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `account` (`account`),
  UNIQUE KEY `telephone` (`telephone`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin001','pass1234','Alice','12345678901'),(2,'admin002','pass5678','Bob','12345678902'),(3,'admin003','pass91011','Charlie','12345678903'),(4,'suyihang','123456','苏一行','18831211608');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `ISBN` char(10) NOT NULL COMMENT 'ISBN编号',
  `title` varchar(20) NOT NULL COMMENT '书名',
  `author` varchar(12) NOT NULL COMMENT '作者',
  `publisher` varchar(20) NOT NULL COMMENT '出版社',
  `publication_date` date NOT NULL COMMENT '出版日期',
  `total` int NOT NULL COMMENT '总量',
  `price` decimal(6,2) NOT NULL COMMENT '价格',
  `type_id` int NOT NULL COMMENT '类型',
  PRIMARY KEY (`ISBN`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `type` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='书籍表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES ('1234567800','Book Title 11','Author 11','Publisher 11','2016-11-15',190,84.99,1),('1234567801','Book Title 12','Author 12','Publisher 12','2021-12-05',210,94.99,2),('1234567802','Book Title 13','Author 13','Publisher 13','2020-01-25',220,104.99,3),('1234567803','Book Title 14','Author 14','Publisher 14','2019-02-14',230,114.99,4),('1234567804','Book Title 15','Author 15','Publisher 15','2018-03-05',240,124.99,5),('1234567805','Book Title 16','Author 16','Publisher 16','2017-04-25',250,134.99,1),('1234567806','Book Title 17','Author 17','Publisher 17','2016-05-15',260,144.99,2),('1234567807','Book Title 18','Author 18','Publisher 18','2021-06-05',270,154.99,3),('1234567808','Book Title 19','Author 19','Publisher 19','2020-07-15',280,164.99,4),('1234567809','Book Title 20','Author 20','Publisher 20','2019-08-05',290,174.99,5),('1234567890','Book Title 1','Author 1','Publisher 1','2020-01-01',100,29.99,1),('1234567891','Book Title 2','Author 2','Publisher 2','2019-02-15',150,39.99,2),('1234567892','Book Title 3','Author 3','Publisher 3','2018-03-20',200,49.99,3),('1234567893','Book Title 4','Author 4','Publisher 4','2017-04-10',120,19.99,4),('1234567894','Book Title 5','Author 5','Publisher 5','2016-05-05',130,24.99,5),('1234567895','Book Title 6','Author 6','Publisher 6','2021-06-30',110,34.99,1),('1234567896','Book Title 7','Author 7','Publisher 7','2020-07-25',140,44.99,2),('1234567897','Book Title 8','Author 8','Publisher 8','2019-08-15',160,54.99,3),('1234567898','Book Title 9','Author 9','Publisher 9','2018-09-05',170,64.99,4),('1234567899','Book Title 10','Author 10','Publisher 10','2017-10-25',180,74.99,5);
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `before_book_delete` BEFORE DELETE ON `book` FOR EACH ROW BEGIN
    IF EXISTS (SELECT 1 FROM borrow WHERE ISBN = OLD.ISBN AND borrow.actual_return_time IS NULL) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete book because there are active borrow records.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `borrow`
--

DROP TABLE IF EXISTS `borrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `borrow` (
  `borrow_id` int NOT NULL AUTO_INCREMENT COMMENT '记录编号',
  `student_id` char(12) NOT NULL COMMENT '学号',
  `ISBN` char(10) NOT NULL COMMENT 'ISBN编号',
  `borrow_time` date NOT NULL COMMENT '借阅时间',
  `return_time` date NOT NULL COMMENT '应归还时间',
  `actual_return_time` date DEFAULT NULL COMMENT '实际归还时间',
  PRIMARY KEY (`borrow_id`),
  KEY `student_id` (`student_id`),
  KEY `ISBN` (`ISBN`),
  CONSTRAINT `borrow_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `borrow_ibfk_2` FOREIGN KEY (`ISBN`) REFERENCES `book` (`ISBN`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='借阅记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow`
--

LOCK TABLES `borrow` WRITE;
/*!40000 ALTER TABLE `borrow` DISABLE KEYS */;
INSERT INTO `borrow` VALUES (11,'S10001','1234567890','2024-01-10','2024-01-20','2024-07-18'),(12,'S10002','1234567891','2024-02-15','2024-02-25','2024-06-28'),(13,'S10003','1234567892','2024-03-20','2024-03-30','2024-06-20'),(14,'S10004','1234567893','2024-04-10','2024-04-20','2024-06-27'),(15,'S10005','1234567894','2024-05-05','2024-05-15',NULL),(16,'S10006','1234567894','2024-06-05','2024-06-27','2024-07-08'),(22,'S10005','1234567890','2024-07-02','2024-07-09','2024-07-08'),(23,'suyihang','1234567801','2024-07-09','2024-07-18','2024-07-10'),(24,'suyihang','1234567801','2024-07-09','2024-07-24','2024-07-12'),(25,'suyihang','1234567801','2024-07-09','2024-07-25','2024-07-10'),(26,'suyihang','1234567801','2024-07-09','2024-07-12','2024-07-10'),(27,'S10001','1234567801','2024-07-09','2024-07-24',NULL),(28,'S10001','1234567897','2024-07-09','2024-07-18',NULL),(29,'S10001','1234567800','2024-07-09','2024-07-10',NULL),(30,'suyihang','1234567802','2024-07-10','2024-08-02','2024-07-11'),(31,'suyihang','1234567808','2024-07-10','2024-07-17','2024-07-10'),(32,'suyihang','1234567800','2024-07-10','2024-07-10','2024-07-10'),(33,'suyihang','1234567800','2024-07-10','2024-07-19','2024-07-10'),(34,'suyihang','1234567803','2024-07-10','2024-07-27','2024-07-11'),(35,'suyihang','1234567893','2024-07-10','2024-07-25','2024-07-12'),(36,'suyihang','1234567802','2024-07-10','2024-07-19','2024-07-10'),(37,'suyihang','1234567802','2024-07-11','2024-07-27','2024-07-11'),(43,'suyihang','1234567800','2024-07-11','2024-08-03','2024-07-11'),(44,'suyihang','1234567809','2024-07-11','2024-07-27','2024-07-11'),(45,'suyihang','1234567802','2024-07-11','2024-07-26',NULL),(46,'suyihang','1234567800','2024-07-12','2024-07-26',NULL),(47,'suyihang','1234567804','2024-07-12','2024-07-26',NULL);
/*!40000 ALTER TABLE `borrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit`
--

DROP TABLE IF EXISTS `credit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit` (
  `student_id` char(12) NOT NULL COMMENT '学号',
  `borrow_times` int NOT NULL DEFAULT '0' COMMENT '总借阅次数',
  `late_return_times` int NOT NULL DEFAULT '0' COMMENT '延迟归还次数',
  `credit_value` tinyint NOT NULL DEFAULT '100' COMMENT '信誉积分',
  `credit_rating` char(5) NOT NULL DEFAULT '优秀' COMMENT '信誉等级',
  `borrow_limit` tinyint NOT NULL DEFAULT '4' COMMENT '借阅上限',
  PRIMARY KEY (`student_id`),
  CONSTRAINT `credit_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学生信誉表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit`
--

LOCK TABLES `credit` WRITE;
/*!40000 ALTER TABLE `credit` DISABLE KEYS */;
INSERT INTO `credit` VALUES ('S10001',0,0,100,'优秀',4),('S10002',0,0,100,'优秀',4),('S10003',0,0,100,'优秀',4),('S10004',0,0,100,'优秀',4),('S10005',0,0,100,'优秀',4),('S10006',0,0,100,'优秀',4),('S10007',0,0,100,'优秀',4),('S10008',0,0,100,'优秀',4),('S10009',0,0,100,'优秀',4),('S10010',0,0,100,'优秀',4),('S10011',0,0,100,'优秀',4),('S10012',0,0,100,'优秀',4),('S10013',0,0,100,'优秀',4),('S10014',0,0,100,'优秀',4),('S10015',0,0,100,'优秀',4),('S10016',0,0,100,'优秀',4),('S10017',0,0,100,'优秀',4),('S10018',0,0,100,'优秀',4),('S10019',0,0,100,'优秀',4),('S10020',0,0,100,'优秀',4);
/*!40000 ALTER TABLE `credit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lose`
--

DROP TABLE IF EXISTS `lose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lose` (
  `lose_id` int NOT NULL AUTO_INCREMENT,
  `student_id` char(12) NOT NULL,
  `ISBN` char(10) NOT NULL,
  `status` varchar(5) NOT NULL,
  `report_time` date NOT NULL,
  `is_compensation` tinyint(1) NOT NULL,
  `remark` text,
  PRIMARY KEY (`lose_id`),
  KEY `student_id` (`student_id`),
  KEY `ISBN` (`ISBN`),
  CONSTRAINT `lose_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`),
  CONSTRAINT `lose_ibfk_2` FOREIGN KEY (`ISBN`) REFERENCES `book` (`ISBN`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lose`
--

LOCK TABLES `lose` WRITE;
/*!40000 ALTER TABLE `lose` DISABLE KEYS */;
INSERT INTO `lose` VALUES (1,'S10001','1234567890','丢失','2024-06-30',0,'丢失在图书馆'),(2,'S10002','1234567891','损坏','2024-06-30',1,'封面破损'),(3,'S10003','1234567892','丢失','2024-06-30',0,'借书后丢失'),(4,'S10004','1234567893','损坏','2024-06-30',1,'内页撕破'),(5,'S10005','1234567894','丢失','2024-06-30',0,'不小心丢失'),(8,'suyihang','1234567801','损坏','2024-07-10',1,'封面损坏'),(9,'suyihang','1234567801','损坏','2024-07-10',1,'封面损坏'),(10,'suyihang','1234567809','损坏','2024-07-11',1,'封面损坏');
/*!40000 ALTER TABLE `lose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `student_id` char(12) NOT NULL COMMENT '学号',
  `password` varchar(12) NOT NULL COMMENT '密码',
  `student_name` varchar(12) NOT NULL COMMENT '姓名',
  `gender` char(2) NOT NULL COMMENT '性别',
  `faculty` varchar(20) NOT NULL COMMENT '所在学院',
  `year` date NOT NULL COMMENT '入学年份',
  `telephone` char(11) NOT NULL COMMENT '联系电话',
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `telephone` (`telephone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学生表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('2201004039','2201004039','姬思文','女','计算机科学与工程学院','2022-09-01','18821211237'),('2204001156','2204001156','郑程元','男','计算机科学与工程学院','2022-09-01','18821211216'),('2204001188','2204001188','代拴拴','男','计算机科学与工程学院','2022-09-01','18821211214'),('2205006032','2205006032','马丽荷','女','计算机科学与工程学院','2022-09-01','18821211243'),('2205006045','2205006045','毛桃花','女','计算机科学与工程学院','2022-09-01','18821211241'),('2205006066','2205006066','闫佳弟','女','计算机科学与工程学院','2022-09-01','18821211245'),('2205006071','2205006071','马啸','男','计算机科学与工程学院','2022-09-01','18821211217'),('2205006083','2205006083','撒海丽','女','计算机科学与工程学院','2022-09-01','18821211247'),('2205006085','2205006085','吴煜鹏','男','计算机科学与工程学院','2022-09-01','18821211225'),('2205006093','2205006093','李鑫','女','计算机科学与工程学院','2022-09-01','18821211248'),('2205006114','2205006114','马学琴','女','计算机科学与工程学院','2022-09-01','18821211246'),('2205006125','2205006125','钱子杰','女','计算机科学与工程学院','2022-09-01','18821211244'),('2205006146','2205006146','刘皓天','男','计算机科学与工程学院','2022-09-01','18821211227'),('2205006157','2205006157','李文竹','女','计算机科学与工程学院','2022-09-01','18821211240'),('2205006169','2205006169','李明杰','男','计算机科学与工程学院','2022-09-01','18821211223'),('2205006182','2205006182','顾槟','男','计算机科学与工程学院','2022-09-01','18821211215'),('2205006192','2205006192','陈雨晨','女','计算机科学与工程学院','2022-09-01','18821211234'),('2205006193','2205006193','刘腾壕','男','计算机科学与工程学院','2022-09-01','18821211219'),('2205006194','2205006194','济振国','男','计算机科学与工程学院','2022-09-01','18821211229'),('2205006199','2205006199','顾倩伊','女','计算机科学与工程学院','2022-09-01','18821211235'),('2205006212','2205006212','杨健新','男','计算机科学与工程学院','2022-09-01','18821211220'),('2205006224','2205006224','苏一行','男','计算机科学与工程学院','2022-09-01','18821211224'),('2205006225','2205006225','谢佳旋','女','计算机科学与工程学院','2022-09-01','18821211233'),('2205006301','2205006301','谭杰冰','女','计算机科学与工程学院','2022-09-01','18821211232'),('2205006314','2205006314','马萌斌','男','计算机科学与工程学院','2022-09-01','18821211218'),('2205006322','2205006322','郭雨馨','女','计算机科学与工程学院','2022-09-01','18821211242'),('2205006343','2205006343','熊芷薇','女','计算机科学与工程学院','2022-09-01','18821211239'),('2205006349','2205006349','段欣宇','男','计算机科学与工程学院','2022-09-01','18821211221'),('2205006358','2205006358','高代芬','女','计算机科学与工程学院','2022-09-01','18821211236'),('2205006373','2205006373','张坚','男','计算机科学与工程学院','2022-09-01','18821211213'),('2205006403','2205006403','王长春','男','计算机科学与工程学院','2022-09-01','18821211228'),('2205006418','2205006418','高燊','男','计算机科学与工程学院','2022-09-01','18821211231'),('2205006436','2205006436','王佳驰','男','计算机科学与工程学院','2022-09-01','18821211230'),('2205006465','2205006465','樊策','男','计算机科学与工程学院','2022-09-01','18821211226'),('2205006466','2205006466','刘宇彤','女','计算机科学与工程学院','2022-09-01','18821211238'),('2205006510','2205006510','顾秋炜','男','计算机科学与工程学院','2022-09-01','18821211222'),('S10001','password1','Alice','女','Engineering','2020-09-01','12345678901'),('S10002','password2','Bob','男','Science','2019-09-01','12345678902'),('S10003','password3','Charlie','男','Arts','2021-09-01','12345678903'),('S10004','password4','Diana','女','Medicine','2020-09-01','12345678904'),('S10005','password5','Eve','女','Law','2019-09-01','12345678905'),('S10006','password6','Frank','男','Business','2021-09-01','12345678906'),('S10007','password7','Grace','女','Education','2020-09-01','12345678907'),('S10008','password8','Hank','男','Engineering','2019-09-01','12345678908'),('S10009','password9','Ivy','女','Science','2021-09-01','12345678909'),('S10010','password10','Jack','男','Arts','2020-09-01','12345678910'),('S10011','password11','Kelly','女','Medicine','2019-09-01','12345678911'),('S10012','password12','Leo','男','Law','2021-09-01','12345678912'),('S10013','password13','Mona','女','Business','2020-09-01','12345678913'),('S10014','password14','Nina','女','Education','2019-09-01','12345678914'),('S10015','password15','Oscar','男','Engineering','2021-09-01','12345678915'),('S10016','password16','Paul','男','Science','2020-09-01','12345678916'),('S10017','password17','Quincy','男','Arts','2019-09-01','12345678917'),('S10018','password18','Rachel','女','Medicine','2021-09-01','12345678918'),('S10019','password19','Steve','男','Law','2020-09-01','12345678919'),('S10020','password20','Tina','女','Business','2019-09-01','12345678920'),('suyihang','123123','苏一行','男','计算机科学与工程学院','2024-07-04','18831211608');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `before_student_delete` BEFORE DELETE ON `student` FOR EACH ROW BEGIN
    IF EXISTS (SELECT 1 FROM borrow WHERE student_id = OLD.student_id AND actual_return_time IS NULL) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete student because there are active borrow records.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `type`
--

DROP TABLE IF EXISTS `type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `type` (
  `type_id` int NOT NULL AUTO_INCREMENT COMMENT '类别ID',
  `type` varchar(10) NOT NULL COMMENT '类别名',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='类别表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type`
--

LOCK TABLES `type` WRITE;
/*!40000 ALTER TABLE `type` DISABLE KEYS */;
INSERT INTO `type` VALUES (1,'小说'),(2,'历史'),(3,'科技'),(4,'文学'),(5,'教育');
/*!40000 ALTER TABLE `type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-12 12:35:03
